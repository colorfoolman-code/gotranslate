# 第 12 章《构建 SeatKeeper 预订 API》终审报告

## 1. 终审范围

本报告覆盖以下交付物：

- 中文正文：`chapters/chapter12_seatkeeper_api.tex`
- 合并 PDF：`main.pdf`
- 完整代码：`code/chapter12-seatkeeper/`
- OpenAPI：`code/chapter12-seatkeeper/api/openapi.yaml`
- PostgreSQL 迁移：`code/chapter12-seatkeeper/migrations/000001_initial.sql`
- Docker Compose：`code/chapter12-seatkeeper/docker-compose.yml`

审校目标对应用户提出的三组要求：

1. 与前文及原书风格是否一致，语言是否经过润色；
2. 教学过程是否真正循序渐进，并向新手解释清楚概念；
3. 代码、测试、文档和最终 PDF 是否形成可验证的完整交付。

## 2. 开工前资料阅读结论

详细研究见 `CH12_SOURCE_STYLE_RESEARCH.md`。本章写作前完成了三类阅读：

- 课程设计与生产流程：确定 SeatKeeper 五章连续项目的边界、checkpoint、标签和后续演进路线；
- 英文原版完整章节：阅读 “Gordle as a service”，提炼情景开场、需求/非目标、最小竖切面、边做边测、明确限制和章末悬念等方法；
- 现有中文第 10、11 章：核对中文语气、术语处理、代码清单、深色终端框、提示/警告框、页眉页脚和 170 mm × 240 mm 版式。

最终正文没有照搬英文原文，而是采用相同的教学机制：先让读者遇到一个可感知的问题，再以可以运行、观察和测试的小步实现完整系统。

## 3. 语言与风格检查

### 3.1 情景化开头

章节从 Go 社区用共享表格登记热门工作坊开始。覆盖行、缓存未刷新、十四名“已确认”参加者与十二把椅子的冲突，直接建立业务动机。随后自然引出 REST API、PostgreSQL 和连续四章演进，而不是先抛出框架名词。

幽默控制在帮助记忆的范围内，例如：

- “椅子当然不会因为单元格被涂成绿色，就突然学会有丝分裂。”
- “万能函数通常只在一件事上很万能：让后来的人不敢修改它。”
- “那不是 API，那是文字冒险游戏。”

这些句子用于缓解技术密度，没有替代技术解释。

### 3.2 与现有中文章节一致性

正文沿用前文的主要习惯：

- 章首“本章内容”框；
- 先列需求，再列技术要求和非目标；
- 文件名、命令、标识符和 API 字段保持英文；
- 第一次出现的重要概念解释职责、输入、输出和边界；
- 代码清单之后立即解释关键行及设计原因；
- 浅色代码框、深色终端框、信息框、提示框和警告框职责分明；
- 使用“运行—观察—解释—继续”的节奏；
- 章末包含 checkpoint、支线任务和详细小结。

### 3.3 润色检查

终审重点检查了：

- “活动 / 占座 / 席位 / repository / 适配器”等术语是否前后一致；
- 英文标识符周围的中文空格和标点；
- 长句是否拆分，段落是否一次只承担一个主要解释任务；
- 是否存在过度承诺，如把顺序正确误写成并发安全；
- 是否把教学折中、生产限制和后续章节责任写清楚。

本章明确指出：第一版会在顺序请求下工作，但数据库容量更新尚不能抵抗并发竞争；缺少幂等、认证、自动过期、readiness、结构化请求日志和优雅关闭。限制不是藏在脚注里，而是贯穿警告框、代码注释、README、边界章节和小结。

## 4. 教学递进检查

章节按照以下学习曲线推进：

1. **先描述外部行为**：端点、JSON、状态码、统一错误包络；
2. **再建立领域语言**：`Event`、`Reservation`、自定义 `ID`、状态和可用席位；
3. **把错误建模成值**：验证错误、可分类领域错误和 `errors.Is/As`；
4. **组织应用用例**：应用服务、消费者侧小接口、时钟与 ID 生成器注入；
5. **先用 fake 测试规则**：避免一开始就要求读者启动数据库；
6. **增加 HTTP 适配器**：Go 1.22 `ServeMux`、严格 JSON、错误映射和 `httptest`；
7. **再接 PostgreSQL**：schema、迁移、约束、索引、参数化 SQL 和事务；
8. **组装可执行程序**：迁移命令和 API 命令；
9. **启动完整环境**：Docker Compose、`curl` 成功路径和失败路径；
10. **补齐分层测试与 OpenAPI**；
11. **最后检查第一版边界**，为下一章并发测试制造明确问题。

这一顺序避免了两种常见问题：一是先堆满抽象而没有可运行行为，二是一上来把 HTTP、SQL 和业务规则混在同一个 handler 中。

### 4.1 新手解释检查

以下概念均在首次承担主线职责时解释：

- REST 资源、HTTP 方法、`Location`、`201/400/404/409/422/500`；
- 持久化状态与派生值；
- 自定义类型和 UUID；
- 领域错误、错误包装和分类；
- 依赖注入与函数式选项；
- 在使用方定义接口；
- fake、stub 与真实 repository 的区别；
- 严格 JSON 解码和多顶层对象问题；
- `httptest` 为什么不需要真实端口；
- 数据库迁移、约束、普通索引和部分索引；
- 事务能保证什么、不能保证什么；
- test pyramid 和 race detector 的能力边界；
- OpenAPI 与运行时实现必须讲同一个故事。

章节没有要求读者先接受“企业最佳实践”结论，而是用后续需求说明为何需要接口、事务、错误分类和分层测试。

### 4.2 代码体量检查

正文共约：

- 77 个物理页；
- 2,436 行 LaTeX 源文；
- 约 14,869 个汉字；
- 81 个代码、SQL、JSON、YAML、目录树或终端块；
- 4 幅教学图；
- 16 个一级节和 53 个二级节。

正文不会连续倾倒完整文件。关键清单展示当前学习目标，重复的样板或完整断言会明确指向代码包。配套工程总计约 2,441 行 Go、SQL、YAML、Shell、Markdown 和构建文件，足以形成真实项目，又没有提前塞入后续四章的并发、Outbox、worker、SSE 和生产可观测性。

## 5. 技术一致性检查

### 5.1 HTTP 路由与 OpenAPI

自动检查读取 `internal/httpapi/server.go` 和 `api/openapi.yaml`。两边均包含以下六个方法/路径组合：

```text
GET  /healthz
POST /v1/events
GET  /v1/events
GET  /v1/events/{eventID}
POST /v1/events/{eventID}/reservations
GET  /v1/reservations/{reservationID}
```

检查结果：

```text
missing_from_openapi: []
missing_from_implementation: []
```

完整结果见 `CH12_CONTRACT_AND_PDF_SCAN.json`。

### 5.2 领域、HTTP 和数据库边界

- HTTP request DTO 不直接充当数据库模型；
- 应用服务只依赖 `booking.Repository`；
- HTTP 适配器只声明自己需要的用例接口；
- PostgreSQL 适配器负责 SQL 与 SQLSTATE 翻译；
- `CreateReservation` 的两项写操作位于同一事务；
- 迁移包含外键、字段范围检查、排序索引和过期 hold 的部分索引；
- `available_seats` 由 `capacity - reserved_seats` 计算，不保存第二份真相；
- 当前“先读后写”算法被明确标为下一章要替换的教学边界。

### 5.3 离线审阅环境的数据库驱动

工程没有第三方 Go module。`internal/pgdriver` 通过系统 `libpq` 实现 `database/sql` 驱动，以便当前离线环境完成构建和测试。README 明确说明，真实生产项目通常应优先考虑维护成熟的 `pgx/v5`。正文没有把这一交付便利包装成唯一正确选择。

## 6. 实际代码验证

最终验证日志：`CH12_CODE_VERIFICATION_FINAL.log`。

在 Go 1.23.2、Linux/amd64 环境中实际运行并通过：

```text
gofmt check
CGO_ENABLED=1 go test ./...
CGO_ENABLED=1 go test -race ./...
CGO_ENABLED=1 go vet ./...
CGO_ENABLED=1 go build ./...
```

结果包括：

- `internal/booking` 单元测试通过；
- `internal/httpapi` HTTP 契约测试通过；
- `internal/pgdriver` 测试通过；
- `internal/platform/migrate` 测试通过；
- 两个 `cmd` 程序完成编译；
- race detector 未发现进程内数据竞争。

执行了：

```text
CGO_ENABLED=1 go test -v -tags=integration ./internal/postgres
```

集成测试成功编译并启动，但因当前环境没有 PostgreSQL 服务、没有 Docker daemon，且未设置 `SEATKEEPER_TEST_DATABASE_URL`，按测试设计显示 `SKIP`。因此，本报告不声称真实 PostgreSQL 往返已经在本环境完成。读者在一次性数据库中设置该变量后，测试会运行迁移、清空本章表、写入并重新读取活动和占座。

## 7. PDF 与版式终审

### 7.1 编译信息

- 合并 PDF：598 个物理页；
- 页面尺寸：481.89 × 680.31 pt，约等于 170 mm × 240 mm；
- 第 12 章：物理页 522--598，共 77 页；
- 书内页码：508--584；
- 第 12 章超过用户要求的 50 页。

### 7.2 预检

`pdf_preflight.py` 最终结果：

```json
{
  "ok_open": true,
  "encrypted": false,
  "pages": 598,
  "likely_scanned": false,
  "xfa_present": false,
  "warnings": []
}
```

详见 `PDF_PREFLIGHT_CH12_FINAL.json`。

### 7.3 渲染抽检

使用 Poppler `pdftoppm` 渲染并人工检查了物理页：

```text
11, 13, 522, 524, 530, 545, 558, 570, 583, 587, 589, 594, 597, 598
```

覆盖目录、章首、架构图、表格、Go 代码、JSON、关系模型、SQL、Docker 命令、测试金字塔、边界分析、checkpoint、练习和小结。抽检结果：

- 没有裁切、重叠、黑方块或破损字形；
- 代码框、终端框和标题条边界完整；
- TikZ 图未越出正文区域；
- 末页的小结完整显示；
- 页眉页脚和页码延续前文章节。

终审过程中发现深色终端框在一次分页后可能把白色文字状态泄漏到普通正文。已在每个 `shellcode` 环境后显式恢复 `PocketInk`，重新编译并对第 12 章 77 页执行文本颜色扫描。最终结果：

```text
unexpected_white_serif_spans: 0
```

抽检图片保存在 `review/renders_ch12_final/`。

## 8. 最终结论

第 12 章已经达到本轮交付目标：

- 写作机制与英文原版、中文前文章节保持一致，但内容是独立原创；
- 从情景、契约、领域、服务、HTTP、数据库到部署和测试逐步推进；
- 关键概念面向新手解释，代码清单后有原因、边界和验证方式；
- 正文与完整代码 checkpoint、OpenAPI、迁移和 Docker 配置形成同一个系统；
- Go 单元测试、HTTP 测试、race、vet 和 build 已实际通过；
- PDF 共 598 页，第 12 章 77 页，完成预检和代表页渲染审校；
- 唯一未在当前环境实跑的是依赖真实 PostgreSQL 的往返测试，该限制已在正文、README、日志和本报告中明确记录。
