module example.com/seatkeeper

go 1.23
