#!/usr/bin/env sh
set -eu

base_url=${BASE_URL:-http://localhost:8080}
starts_at=$(date -u -d '+2 days' '+%Y-%m-%dT%H:%M:%SZ' 2>/dev/null || date -u -v+2d '+%Y-%m-%dT%H:%M:%SZ')

event_json=$(curl -fsS -X POST "$base_url/v1/events" \
  -H 'Content-Type: application/json' \
  -d "{\"name\":\"Go in the Park\",\"starts_at\":\"$starts_at\",\"capacity\":20}")
printf '%s\n' "$event_json"

event_id=$(printf '%s' "$event_json" | python3 -c 'import json,sys; print(json.load(sys.stdin)["id"])')

reservation_json=$(curl -fsS -X POST "$base_url/v1/events/$event_id/reservations" \
  -H 'Content-Type: application/json' \
  -d '{"customer_name":"Ada Lovelace","customer_email":"ada@example.com","seats":2}')
printf '%s\n' "$reservation_json"

reservation_id=$(printf '%s' "$reservation_json" | python3 -c 'import json,sys; print(json.load(sys.stdin)["id"])')
curl -fsS "$base_url/v1/events/$event_id"; printf '\n'
curl -fsS "$base_url/v1/reservations/$reservation_id"; printf '\n'
