package migrate

import (
	"reflect"
	"testing"
)

func TestStatements(t *testing.T) {
	t.Parallel()

	got := statements(`-- +migrate Up
CREATE TABLE events (id uuid PRIMARY KEY);
CREATE INDEX events_id_idx ON events (id);
-- +migrate Down`)
	want := []string{
		"CREATE TABLE events (id uuid PRIMARY KEY)",
		"CREATE INDEX events_id_idx ON events (id)",
		"-- +migrate Down",
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("statements() = %#v, want %#v", got, want)
	}
}
