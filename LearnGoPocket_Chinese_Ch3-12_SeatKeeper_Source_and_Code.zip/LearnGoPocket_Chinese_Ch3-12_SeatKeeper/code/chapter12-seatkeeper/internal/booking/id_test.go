package booking

import (
	"strings"
	"testing"
)

func TestNewID(t *testing.T) {
	t.Parallel()

	id, err := NewID()
	if err != nil {
		t.Fatalf("NewID() error = %v", err)
	}
	if _, err := ParseID(string(id)); err != nil {
		t.Fatalf("ParseID(%q) error = %v", id, err)
	}
	if id[14] != '4' {
		t.Fatalf("UUID version nibble = %q, want 4", id[14])
	}
	if !strings.Contains("89ab", strings.ToLower(string(id[19]))) {
		t.Fatalf("UUID variant nibble = %q, want one of 8, 9, a, b", id[19])
	}
}

func TestParseIDRejectsInvalidValue(t *testing.T) {
	t.Parallel()

	if _, err := ParseID("not-an-id"); err == nil {
		t.Fatal("ParseID() error = nil, want an error")
	}
}
