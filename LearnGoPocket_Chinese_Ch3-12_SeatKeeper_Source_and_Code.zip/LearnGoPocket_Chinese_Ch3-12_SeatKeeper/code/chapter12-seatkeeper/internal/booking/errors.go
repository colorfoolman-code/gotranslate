package booking

import (
	"errors"
	"fmt"
	"sort"
	"strings"
)

var (
	ErrNotFound         = errors.New("not found")
	ErrNoSeatsAvailable = errors.New("not enough seats available")
	ErrEventStarted     = errors.New("event has already started")
	ErrConflict         = errors.New("conflict")
)

// ValidationError contains one readable error per invalid input field.
type ValidationError struct {
	Fields map[string]string
}

func (e ValidationError) Error() string {
	if len(e.Fields) == 0 {
		return "validation failed"
	}
	keys := make([]string, 0, len(e.Fields))
	for key := range e.Fields {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	parts := make([]string, 0, len(keys))
	for _, key := range keys {
		parts = append(parts, fmt.Sprintf("%s: %s", key, e.Fields[key]))
	}
	return "validation failed: " + strings.Join(parts, "; ")
}
