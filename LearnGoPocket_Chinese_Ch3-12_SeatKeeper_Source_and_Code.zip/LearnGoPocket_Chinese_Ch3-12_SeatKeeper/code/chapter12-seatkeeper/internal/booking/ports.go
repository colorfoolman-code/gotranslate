package booking

import "context"

// Repository is defined by the service that consumes it. The PostgreSQL
// adapter and the test fake both implement this small interface.
type Repository interface {
	CreateEvent(context.Context, Event) error
	ListEvents(context.Context, int) ([]Event, error)
	EventByID(context.Context, ID) (Event, error)
	CreateReservation(context.Context, Reservation, int) error
	ReservationByID(context.Context, ID) (Reservation, error)
}
