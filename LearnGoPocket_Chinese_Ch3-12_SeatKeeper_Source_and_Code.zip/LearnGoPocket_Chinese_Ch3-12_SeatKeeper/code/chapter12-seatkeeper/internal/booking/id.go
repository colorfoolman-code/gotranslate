package booking

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
)

// ID is the identifier used by SeatKeeper resources.
type ID string

// NewID returns a random UUID version 4 without requiring a third-party module.
func NewID() (ID, error) {
	var raw [16]byte
	if _, err := rand.Read(raw[:]); err != nil {
		return "", fmt.Errorf("generate id: %w", err)
	}

	// RFC 4122 version and variant bits.
	raw[6] = (raw[6] & 0x0f) | 0x40
	raw[8] = (raw[8] & 0x3f) | 0x80

	buf := make([]byte, 36)
	hex.Encode(buf[0:8], raw[0:4])
	buf[8] = '-'
	hex.Encode(buf[9:13], raw[4:6])
	buf[13] = '-'
	hex.Encode(buf[14:18], raw[6:8])
	buf[18] = '-'
	hex.Encode(buf[19:23], raw[8:10])
	buf[23] = '-'
	hex.Encode(buf[24:36], raw[10:16])
	return ID(buf), nil
}

// ParseID validates the textual UUID form accepted by the API.
func ParseID(value string) (ID, error) {
	if len(value) != 36 || value[8] != '-' || value[13] != '-' || value[18] != '-' || value[23] != '-' {
		return "", fmt.Errorf("invalid id %q", value)
	}

	compact := make([]byte, 0, 32)
	for i := range value {
		if value[i] != '-' {
			compact = append(compact, value[i])
		}
	}
	if _, err := hex.Decode(make([]byte, 16), compact); err != nil {
		return "", fmt.Errorf("invalid id %q: %w", value, err)
	}
	return ID(value), nil
}
