package booking

import "time"

const (
	MaxEventCapacity = 1_000
	MaxSeatsPerHold  = 10
	DefaultHoldTime  = 10 * time.Minute
)

// ReservationStatus describes the small state machine available in chapter 12.
type ReservationStatus string

const (
	ReservationHeld ReservationStatus = "held"
)

// Event is a bookable workshop, meetup, or conference session.
type Event struct {
	ID            ID        `json:"id"`
	Name          string    `json:"name"`
	StartsAt      time.Time `json:"starts_at"`
	Capacity      int       `json:"capacity"`
	ReservedSeats int       `json:"reserved_seats"`
	CreatedAt     time.Time `json:"created_at"`
}

// AvailableSeats reports the number of seats not currently held.
func (e Event) AvailableSeats() int {
	return e.Capacity - e.ReservedSeats
}

// Reservation represents a temporary seat hold.
type Reservation struct {
	ID            ID                `json:"id"`
	EventID       ID                `json:"event_id"`
	CustomerName  string            `json:"customer_name"`
	CustomerEmail string            `json:"customer_email"`
	Seats         int               `json:"seats"`
	Status        ReservationStatus `json:"status"`
	ExpiresAt     time.Time         `json:"expires_at"`
	CreatedAt     time.Time         `json:"created_at"`
}

// CreateEventInput is the information accepted by the create-event use case.
type CreateEventInput struct {
	Name     string
	StartsAt time.Time
	Capacity int
}

// CreateReservationInput is the information accepted by the create-reservation use case.
type CreateReservationInput struct {
	EventID       ID
	CustomerName  string
	CustomerEmail string
	Seats         int
}
