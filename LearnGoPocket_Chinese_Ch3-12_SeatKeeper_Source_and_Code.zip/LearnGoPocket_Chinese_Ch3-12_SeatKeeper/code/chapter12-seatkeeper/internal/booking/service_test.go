package booking

import (
	"context"
	"errors"
	"reflect"
	"sort"
	"sync"
	"testing"
	"time"
)

var fixedNow = time.Date(2026, time.October, 3, 10, 0, 0, 0, time.UTC)

type fakeRepository struct {
	mu           sync.Mutex
	events       map[ID]Event
	reservations map[ID]Reservation
	createErr    error
}

func newFakeRepository() *fakeRepository {
	return &fakeRepository{
		events:       map[ID]Event{},
		reservations: map[ID]Reservation{},
	}
}

func (f *fakeRepository) CreateEvent(_ context.Context, event Event) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.createErr != nil {
		return f.createErr
	}
	f.events[event.ID] = event
	return nil
}

func (f *fakeRepository) ListEvents(_ context.Context, limit int) ([]Event, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	events := make([]Event, 0, len(f.events))
	for _, event := range f.events {
		events = append(events, event)
	}
	sort.Slice(events, func(i, j int) bool {
		return events[i].StartsAt.Before(events[j].StartsAt)
	})
	if len(events) > limit {
		events = events[:limit]
	}
	return events, nil
}

func (f *fakeRepository) EventByID(_ context.Context, id ID) (Event, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	event, ok := f.events[id]
	if !ok {
		return Event{}, ErrNotFound
	}
	return event, nil
}

func (f *fakeRepository) CreateReservation(_ context.Context, reservation Reservation, newReservedSeats int) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.createErr != nil {
		return f.createErr
	}
	event, ok := f.events[reservation.EventID]
	if !ok {
		return ErrNotFound
	}
	event.ReservedSeats = newReservedSeats
	f.events[event.ID] = event
	f.reservations[reservation.ID] = reservation
	return nil
}

func (f *fakeRepository) ReservationByID(_ context.Context, id ID) (Reservation, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	reservation, ok := f.reservations[id]
	if !ok {
		return Reservation{}, ErrNotFound
	}
	return reservation, nil
}

func sequenceIDs(ids ...ID) func() (ID, error) {
	var mu sync.Mutex
	return func() (ID, error) {
		mu.Lock()
		defer mu.Unlock()
		if len(ids) == 0 {
			return "", errors.New("no test ids left")
		}
		id := ids[0]
		ids = ids[1:]
		return id, nil
	}
}

func TestCreateEvent(t *testing.T) {
	t.Parallel()

	repo := newFakeRepository()
	service := NewService(
		repo,
		WithClock(func() time.Time { return fixedNow }),
		WithIDGenerator(sequenceIDs("00000000-0000-4000-8000-000000000001")),
	)

	got, err := service.CreateEvent(context.Background(), CreateEventInput{
		Name:     "  Go in the Park  ",
		StartsAt: fixedNow.Add(24 * time.Hour),
		Capacity: 80,
	})
	if err != nil {
		t.Fatalf("CreateEvent() error = %v", err)
	}

	want := Event{
		ID:        "00000000-0000-4000-8000-000000000001",
		Name:      "Go in the Park",
		StartsAt:  fixedNow.Add(24 * time.Hour),
		Capacity:  80,
		CreatedAt: fixedNow,
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("CreateEvent() = %#v, want %#v", got, want)
	}
}

func TestCreateEventValidation(t *testing.T) {
	t.Parallel()

	tests := map[string]CreateEventInput{
		"short name": {
			Name: "Go", StartsAt: fixedNow.Add(time.Hour), Capacity: 10,
		},
		"event too soon": {
			Name: "Go meetup", StartsAt: fixedNow.Add(5 * time.Minute), Capacity: 10,
		},
		"zero capacity": {
			Name: "Go meetup", StartsAt: fixedNow.Add(time.Hour), Capacity: 0,
		},
	}

	for name, input := range tests {
		name, input := name, input
		t.Run(name, func(t *testing.T) {
			t.Parallel()
			service := NewService(newFakeRepository(), WithClock(func() time.Time { return fixedNow }))
			_, err := service.CreateEvent(context.Background(), input)
			var validationErr ValidationError
			if !errors.As(err, &validationErr) {
				t.Fatalf("CreateEvent() error = %v, want ValidationError", err)
			}
		})
	}
}

func TestCreateReservation(t *testing.T) {
	t.Parallel()

	repo := newFakeRepository()
	repo.events["00000000-0000-4000-8000-000000000010"] = Event{
		ID:            "00000000-0000-4000-8000-000000000010",
		Name:          "Go in the Park",
		StartsAt:      fixedNow.Add(24 * time.Hour),
		Capacity:      20,
		ReservedSeats: 4,
		CreatedAt:     fixedNow.Add(-time.Hour),
	}
	service := NewService(
		repo,
		WithClock(func() time.Time { return fixedNow }),
		WithIDGenerator(sequenceIDs("00000000-0000-4000-8000-000000000011")),
	)

	got, err := service.CreateReservation(context.Background(), CreateReservationInput{
		EventID:       "00000000-0000-4000-8000-000000000010",
		CustomerName:  "  Ada Lovelace ",
		CustomerEmail: " ADA@example.com ",
		Seats:         3,
	})
	if err != nil {
		t.Fatalf("CreateReservation() error = %v", err)
	}
	if got.CustomerName != "Ada Lovelace" || got.CustomerEmail != "ada@example.com" {
		t.Fatalf("normalized customer = %q <%s>", got.CustomerName, got.CustomerEmail)
	}
	if got.Status != ReservationHeld {
		t.Fatalf("status = %q, want %q", got.Status, ReservationHeld)
	}
	if got.ExpiresAt != fixedNow.Add(DefaultHoldTime) {
		t.Fatalf("expires_at = %v, want %v", got.ExpiresAt, fixedNow.Add(DefaultHoldTime))
	}

	event, _ := repo.EventByID(context.Background(), got.EventID)
	if event.ReservedSeats != 7 {
		t.Fatalf("reserved seats = %d, want 7", event.ReservedSeats)
	}
}

func TestCreateReservationRejectsTooManySeats(t *testing.T) {
	t.Parallel()

	repo := newFakeRepository()
	repo.events["00000000-0000-4000-8000-000000000020"] = Event{
		ID:            "00000000-0000-4000-8000-000000000020",
		Name:          "Small workshop",
		StartsAt:      fixedNow.Add(time.Hour),
		Capacity:      5,
		ReservedSeats: 4,
	}
	service := NewService(repo, WithClock(func() time.Time { return fixedNow }))

	_, err := service.CreateReservation(context.Background(), CreateReservationInput{
		EventID:       "00000000-0000-4000-8000-000000000020",
		CustomerName:  "Grace Hopper",
		CustomerEmail: "grace@example.com",
		Seats:         2,
	})
	if !errors.Is(err, ErrNoSeatsAvailable) {
		t.Fatalf("CreateReservation() error = %v, want ErrNoSeatsAvailable", err)
	}
}

func TestListEventsValidatesLimit(t *testing.T) {
	t.Parallel()

	service := NewService(newFakeRepository())
	_, err := service.ListEvents(context.Background(), 101)
	var validationErr ValidationError
	if !errors.As(err, &validationErr) {
		t.Fatalf("ListEvents() error = %v, want ValidationError", err)
	}
}
