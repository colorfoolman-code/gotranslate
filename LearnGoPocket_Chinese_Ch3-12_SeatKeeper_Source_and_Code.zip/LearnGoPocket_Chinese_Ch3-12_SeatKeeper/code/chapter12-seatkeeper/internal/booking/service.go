package booking

import (
	"context"
	"fmt"
	"net/mail"
	"strings"
	"time"
)

// Service coordinates SeatKeeper use cases without knowing about HTTP or SQL.
type Service struct {
	repo         Repository
	now          func() time.Time
	newID        func() (ID, error)
	holdDuration time.Duration
}

// Option customizes a Service while keeping sensible production defaults.
type Option func(*Service)

// WithClock replaces the wall clock. Tests use it to make timestamps stable.
func WithClock(now func() time.Time) Option {
	return func(s *Service) { s.now = now }
}

// WithIDGenerator replaces ID creation. Tests use deterministic IDs.
func WithIDGenerator(newID func() (ID, error)) Option {
	return func(s *Service) { s.newID = newID }
}

// WithHoldDuration changes how long a reservation remains held.
func WithHoldDuration(duration time.Duration) Option {
	return func(s *Service) { s.holdDuration = duration }
}

// NewService constructs the application service.
func NewService(repo Repository, options ...Option) *Service {
	s := &Service{
		repo:         repo,
		now:          time.Now,
		newID:        NewID,
		holdDuration: DefaultHoldTime,
	}
	for _, option := range options {
		option(s)
	}
	return s
}

// CreateEvent validates and stores a new event.
func (s *Service) CreateEvent(ctx context.Context, input CreateEventInput) (Event, error) {
	input.Name = strings.TrimSpace(input.Name)
	if err := validateEvent(input, s.now()); err != nil {
		return Event{}, err
	}

	id, err := s.newID()
	if err != nil {
		return Event{}, fmt.Errorf("create event id: %w", err)
	}
	now := s.now().UTC()
	event := Event{
		ID:        id,
		Name:      input.Name,
		StartsAt:  input.StartsAt.UTC(),
		Capacity:  input.Capacity,
		CreatedAt: now,
	}
	if err := s.repo.CreateEvent(ctx, event); err != nil {
		return Event{}, fmt.Errorf("create event: %w", err)
	}
	return event, nil
}

// ListEvents returns upcoming events in start-time order.
func (s *Service) ListEvents(ctx context.Context, limit int) ([]Event, error) {
	if limit == 0 {
		limit = 50
	}
	if limit < 1 || limit > 100 {
		return nil, ValidationError{Fields: map[string]string{
			"limit": "must be between 1 and 100",
		}}
	}
	events, err := s.repo.ListEvents(ctx, limit)
	if err != nil {
		return nil, fmt.Errorf("list events: %w", err)
	}
	return events, nil
}

// Event returns one event by identifier.
func (s *Service) Event(ctx context.Context, id ID) (Event, error) {
	event, err := s.repo.EventByID(ctx, id)
	if err != nil {
		return Event{}, fmt.Errorf("get event %s: %w", id, err)
	}
	return event, nil
}

// CreateReservation creates a temporary hold for one or more seats.
//
// This chapter deliberately performs the availability read before the write.
// It is correct for sequential requests, but chapter 13 will make the update
// safe when many requests compete for the final seats.
func (s *Service) CreateReservation(ctx context.Context, input CreateReservationInput) (Reservation, error) {
	input.CustomerName = strings.TrimSpace(input.CustomerName)
	input.CustomerEmail = strings.TrimSpace(strings.ToLower(input.CustomerEmail))
	if err := validateReservation(input); err != nil {
		return Reservation{}, err
	}

	event, err := s.repo.EventByID(ctx, input.EventID)
	if err != nil {
		return Reservation{}, fmt.Errorf("find event: %w", err)
	}
	now := s.now().UTC()
	if !now.Before(event.StartsAt) {
		return Reservation{}, ErrEventStarted
	}
	if input.Seats > event.AvailableSeats() {
		return Reservation{}, ErrNoSeatsAvailable
	}

	id, err := s.newID()
	if err != nil {
		return Reservation{}, fmt.Errorf("create reservation id: %w", err)
	}
	expiresAt := now.Add(s.holdDuration)
	if expiresAt.After(event.StartsAt) {
		expiresAt = event.StartsAt
	}
	reservation := Reservation{
		ID:            id,
		EventID:       input.EventID,
		CustomerName:  input.CustomerName,
		CustomerEmail: input.CustomerEmail,
		Seats:         input.Seats,
		Status:        ReservationHeld,
		ExpiresAt:     expiresAt,
		CreatedAt:     now,
	}

	newReservedSeats := event.ReservedSeats + input.Seats
	if err := s.repo.CreateReservation(ctx, reservation, newReservedSeats); err != nil {
		return Reservation{}, fmt.Errorf("create reservation: %w", err)
	}
	return reservation, nil
}

// Reservation returns one reservation by identifier.
func (s *Service) Reservation(ctx context.Context, id ID) (Reservation, error) {
	reservation, err := s.repo.ReservationByID(ctx, id)
	if err != nil {
		return Reservation{}, fmt.Errorf("get reservation %s: %w", id, err)
	}
	return reservation, nil
}

func validateEvent(input CreateEventInput, now time.Time) error {
	fields := map[string]string{}
	if length := len([]rune(input.Name)); length < 3 || length > 120 {
		fields["name"] = "must contain 3 to 120 characters"
	}
	if input.StartsAt.IsZero() || input.StartsAt.Before(now.Add(15*time.Minute)) {
		fields["starts_at"] = "must be at least 15 minutes in the future"
	}
	if input.Capacity < 1 || input.Capacity > MaxEventCapacity {
		fields["capacity"] = fmt.Sprintf("must be between 1 and %d", MaxEventCapacity)
	}
	if len(fields) > 0 {
		return ValidationError{Fields: fields}
	}
	return nil
}

func validateReservation(input CreateReservationInput) error {
	fields := map[string]string{}
	if input.EventID == "" {
		fields["event_id"] = "is required"
	}
	if length := len([]rune(input.CustomerName)); length < 2 || length > 120 {
		fields["customer_name"] = "must contain 2 to 120 characters"
	}
	address, err := mail.ParseAddress(input.CustomerEmail)
	if err != nil || !strings.Contains(address.Address, "@") {
		fields["customer_email"] = "must be a valid email address"
	}
	if input.Seats < 1 || input.Seats > MaxSeatsPerHold {
		fields["seats"] = fmt.Sprintf("must be between 1 and %d", MaxSeatsPerHold)
	}
	if len(fields) > 0 {
		return ValidationError{Fields: fields}
	}
	return nil
}
