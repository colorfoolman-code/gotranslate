//go:build cgo

package pgdriver

import (
	"testing"
	"time"
)

func TestConvertTextValue(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name  string
		oid   uint32
		value string
		want  any
	}{
		{name: "integer", oid: 23, value: "42", want: int64(42)},
		{name: "boolean", oid: 16, value: "true", want: true},
		{name: "text", oid: 25, value: "Go", want: "Go"},
		{name: "timestamp", oid: 1184, value: "2026-10-03 10:00:00+00", want: time.Date(2026, 10, 3, 10, 0, 0, 0, time.UTC)},
	}
	for _, test := range tests {
		test := test
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()
			got := convertTextValue(test.oid, test.value)
			gotTime, gotIsTime := got.(time.Time)
			wantTime, wantIsTime := test.want.(time.Time)
			if gotIsTime && wantIsTime {
				if !gotTime.Equal(wantTime) {
					t.Fatalf("convertTextValue(%d, %q) = %#v, want %#v", test.oid, test.value, got, test.want)
				}
				return
			}
			if got != test.want {
				t.Fatalf("convertTextValue(%d, %q) = %#v, want %#v", test.oid, test.value, got, test.want)
			}
		})
	}
}
