//go:build !cgo

package pgdriver

// DriverName is kept available so the rest of the project still compiles when
// CGO is disabled. Building the runnable PostgreSQL commands requires CGO and
// libpq; unit tests for the domain and HTTP layers do not.
const DriverName = "seatkeeper-postgres"
