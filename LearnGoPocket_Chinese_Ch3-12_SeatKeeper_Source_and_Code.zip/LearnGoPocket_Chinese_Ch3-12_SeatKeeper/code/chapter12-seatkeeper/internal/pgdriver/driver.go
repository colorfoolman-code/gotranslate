//go:build cgo

// Package pgdriver provides the small database/sql driver used by the chapter
// bundle. It delegates PostgreSQL's wire protocol, TLS, and authentication to
// the system libpq library so the Go examples can remain dependency-free.
package pgdriver

/*
#cgo pkg-config: libpq
#include <libpq-fe.h>
#include <stdlib.h>
*/
import "C"

import (
	"context"
	"database/sql"
	"database/sql/driver"
	"errors"
	"fmt"
	"io"
	"strconv"
	"strings"
	"sync"
	"time"
	"unsafe"
)

const DriverName = "seatkeeper-postgres"

func init() {
	sql.Register(DriverName, &postgresDriver{})
}

type postgresDriver struct{}

func (*postgresDriver) Open(name string) (driver.Conn, error) {
	connectionString := C.CString(name)
	defer C.free(unsafe.Pointer(connectionString))

	connection := C.PQconnectdb(connectionString)
	if connection == nil {
		return nil, errors.New("libpq returned a nil connection")
	}
	if C.PQstatus(connection) != C.CONNECTION_OK {
		message := strings.TrimSpace(C.GoString(C.PQerrorMessage(connection)))
		C.PQfinish(connection)
		return nil, fmt.Errorf("connect to PostgreSQL: %s", message)
	}
	return &conn{connection: connection}, nil
}

// Error is a PostgreSQL error with its five-character SQLSTATE code.
type Error struct {
	Code    string
	Message string
}

func (e *Error) Error() string {
	if e.Code == "" {
		return e.Message
	}
	return e.Code + ": " + e.Message
}

type conn struct {
	mu         sync.Mutex
	connection *C.PGconn
	closed     bool
}

var (
	_ driver.Conn               = (*conn)(nil)
	_ driver.ConnPrepareContext = (*conn)(nil)
	_ driver.ExecerContext      = (*conn)(nil)
	_ driver.QueryerContext     = (*conn)(nil)
	_ driver.ConnBeginTx        = (*conn)(nil)
	_ driver.Pinger             = (*conn)(nil)
	_ driver.SessionResetter    = (*conn)(nil)
	_ driver.Validator          = (*conn)(nil)
)

func (c *conn) Prepare(query string) (driver.Stmt, error) {
	return c.PrepareContext(context.Background(), query)
}

func (c *conn) PrepareContext(ctx context.Context, query string) (driver.Stmt, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if err := c.ensureOpen(); err != nil {
		return nil, err
	}
	return &stmt{connection: c, query: query}, nil
}

func (c *conn) Close() error {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.closed {
		return nil
	}
	C.PQfinish(c.connection)
	c.connection = nil
	c.closed = true
	return nil
}

func (c *conn) Begin() (driver.Tx, error) {
	return c.BeginTx(context.Background(), driver.TxOptions{})
}

func (c *conn) BeginTx(ctx context.Context, options driver.TxOptions) (driver.Tx, error) {
	if options.ReadOnly {
		return nil, errors.New("read-only transactions are not supported by this chapter driver")
	}
	if options.Isolation != driver.IsolationLevel(0) {
		return nil, errors.New("custom isolation levels are not supported by this chapter driver")
	}
	if _, err := c.ExecContext(ctx, "BEGIN", nil); err != nil {
		return nil, err
	}
	return &tx{connection: c}, nil
}

func (c *conn) Ping(ctx context.Context) error {
	_, err := c.ExecContext(ctx, "SELECT 1", nil)
	return err
}

func (c *conn) ResetSession(ctx context.Context) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	return c.ensureOpen()
}

func (c *conn) IsValid() bool {
	return c.ensureOpen() == nil
}

func (c *conn) ExecContext(ctx context.Context, query string, arguments []driver.NamedValue) (driver.Result, error) {
	result, err := c.execute(ctx, query, arguments)
	if err != nil {
		return nil, err
	}
	defer C.PQclear(result)

	status := C.PQresultStatus(result)
	if status != C.PGRES_COMMAND_OK && status != C.PGRES_TUPLES_OK {
		return nil, resultError(result)
	}
	rowsAffected := int64(0)
	if value := C.PQcmdTuples(result); value != nil {
		text := C.GoString(value)
		if text != "" {
			rowsAffected, _ = strconv.ParseInt(text, 10, 64)
		}
	}
	return commandResult(rowsAffected), nil
}

func (c *conn) QueryContext(ctx context.Context, query string, arguments []driver.NamedValue) (driver.Rows, error) {
	result, err := c.execute(ctx, query, arguments)
	if err != nil {
		return nil, err
	}
	status := C.PQresultStatus(result)
	if status != C.PGRES_TUPLES_OK {
		err := resultError(result)
		C.PQclear(result)
		return nil, err
	}

	columns := make([]string, int(C.PQnfields(result)))
	for index := range columns {
		columns[index] = C.GoString(C.PQfname(result, C.int(index)))
	}
	return &rows{result: result, columns: columns, total: int(C.PQntuples(result))}, nil
}

func (c *conn) execute(ctx context.Context, query string, arguments []driver.NamedValue) (*C.PGresult, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.closed || c.connection == nil {
		return nil, driver.ErrBadConn
	}

	queryCString := C.CString(query)
	defer C.free(unsafe.Pointer(queryCString))

	values, freeValues := parameterValues(arguments)
	defer freeValues()
	result := C.PQexecParams(
		c.connection,
		queryCString,
		C.int(len(arguments)),
		nil,
		values,
		nil,
		nil,
		0,
	)
	if result == nil {
		return nil, fmt.Errorf("execute PostgreSQL query: %s", strings.TrimSpace(C.GoString(C.PQerrorMessage(c.connection))))
	}
	if err := ctx.Err(); err != nil {
		C.PQclear(result)
		return nil, err
	}
	return result, nil
}

func (c *conn) ensureOpen() error {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.closed || c.connection == nil || C.PQstatus(c.connection) != C.CONNECTION_OK {
		return driver.ErrBadConn
	}
	return nil
}

func parameterValues(arguments []driver.NamedValue) (**C.char, func()) {
	if len(arguments) == 0 {
		return nil, func() {}
	}

	size := C.size_t(len(arguments)) * C.size_t(unsafe.Sizeof(uintptr(0)))
	memory := C.malloc(size)
	values := unsafe.Slice((**C.char)(memory), len(arguments))
	allocated := make([]*C.char, 0, len(arguments))
	for index, argument := range arguments {
		if argument.Value == nil {
			values[index] = nil
			continue
		}
		value := C.CString(textValue(argument.Value))
		values[index] = value
		allocated = append(allocated, value)
	}
	return (**C.char)(memory), func() {
		for _, value := range allocated {
			C.free(unsafe.Pointer(value))
		}
		C.free(memory)
	}
}

func textValue(value any) string {
	switch value := value.(type) {
	case time.Time:
		return value.UTC().Format(time.RFC3339Nano)
	case bool:
		return strconv.FormatBool(value)
	case []byte:
		return string(value)
	default:
		return fmt.Sprint(value)
	}
}

func resultError(result *C.PGresult) error {
	code := C.GoString(C.PQresultErrorField(result, C.PG_DIAG_SQLSTATE))
	message := strings.TrimSpace(C.GoString(C.PQresultErrorMessage(result)))
	if message == "" {
		message = "PostgreSQL query failed"
	}
	return &Error{Code: code, Message: message}
}

type commandResult int64

func (commandResult) LastInsertId() (int64, error) {
	return 0, errors.New("PostgreSQL does not expose LastInsertId")
}
func (r commandResult) RowsAffected() (int64, error) { return int64(r), nil }

type rows struct {
	result  *C.PGresult
	columns []string
	current int
	total   int
}

func (r *rows) Columns() []string { return r.columns }

func (r *rows) Close() error {
	if r.result != nil {
		C.PQclear(r.result)
		r.result = nil
	}
	return nil
}

func (r *rows) Next(destination []driver.Value) error {
	if r.current >= r.total {
		return io.EOF
	}
	for column := range destination {
		if C.PQgetisnull(r.result, C.int(r.current), C.int(column)) == 1 {
			destination[column] = nil
			continue
		}
		text := C.GoString(C.PQgetvalue(r.result, C.int(r.current), C.int(column)))
		oid := uint32(C.PQftype(r.result, C.int(column)))
		destination[column] = convertTextValue(oid, text)
	}
	r.current++
	return nil
}

func convertTextValue(oid uint32, value string) driver.Value {
	switch oid {
	case 16: // bool
		parsed, err := strconv.ParseBool(value)
		if err == nil {
			return parsed
		}
	case 20, 21, 23: // int8, int2, int4
		parsed, err := strconv.ParseInt(value, 10, 64)
		if err == nil {
			return parsed
		}
	case 700, 701, 1700: // float4, float8, numeric
		parsed, err := strconv.ParseFloat(value, 64)
		if err == nil {
			return parsed
		}
	case 1082, 1114, 1184: // date, timestamp, timestamptz
		if parsed, ok := parsePostgresTime(value); ok {
			return parsed
		}
	}
	return value
}

func parsePostgresTime(value string) (time.Time, bool) {
	layouts := []string{
		"2006-01-02 15:04:05.999999999Z07:00",
		"2006-01-02 15:04:05.999999999Z07",
		"2006-01-02 15:04:05Z07:00",
		"2006-01-02 15:04:05Z07",
		"2006-01-02 15:04:05.999999999",
		"2006-01-02 15:04:05",
		"2006-01-02",
		time.RFC3339Nano,
	}
	for _, layout := range layouts {
		parsed, err := time.Parse(layout, value)
		if err == nil {
			return parsed, true
		}
	}
	return time.Time{}, false
}

type stmt struct {
	connection *conn
	query      string
}

func (*stmt) Close() error  { return nil }
func (*stmt) NumInput() int { return -1 }
func (s *stmt) Exec(arguments []driver.Value) (driver.Result, error) {
	return s.connection.ExecContext(context.Background(), s.query, namedValues(arguments))
}
func (s *stmt) Query(arguments []driver.Value) (driver.Rows, error) {
	return s.connection.QueryContext(context.Background(), s.query, namedValues(arguments))
}

func namedValues(arguments []driver.Value) []driver.NamedValue {
	values := make([]driver.NamedValue, len(arguments))
	for index, value := range arguments {
		values[index] = driver.NamedValue{Ordinal: index + 1, Value: value}
	}
	return values
}

type tx struct {
	connection *conn
	done       bool
}

func (t *tx) Commit() error {
	if t.done {
		return errors.New("transaction already completed")
	}
	t.done = true
	_, err := t.connection.ExecContext(context.Background(), "COMMIT", nil)
	return err
}

func (t *tx) Rollback() error {
	if t.done {
		return errors.New("transaction already completed")
	}
	t.done = true
	_, err := t.connection.ExecContext(context.Background(), "ROLLBACK", nil)
	return err
}
