package postgres

import (
	"context"
	"database/sql"
	"fmt"

	"example.com/seatkeeper/internal/booking"
)

func (s *Store) CreateReservation(
	ctx context.Context,
	reservation booking.Reservation,
	newReservedSeats int,
) error {
	tx, err := s.db.BeginTx(ctx, &sql.TxOptions{})
	if err != nil {
		return fmt.Errorf("begin reservation transaction: %w", err)
	}
	defer tx.Rollback()

	const insertReservation = `
		INSERT INTO reservations (
			id, event_id, customer_name, customer_email, seats,
			status, expires_at, created_at
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`
	if _, err := tx.ExecContext(ctx, insertReservation,
		reservation.ID, reservation.EventID, reservation.CustomerName,
		reservation.CustomerEmail, reservation.Seats, reservation.Status,
		reservation.ExpiresAt, reservation.CreatedAt,
	); err != nil {
		return fmt.Errorf("insert reservation: %w", translateError(err))
	}

	// This absolute write is intentionally the simple chapter-12 version.
	// Chapter 13 replaces it with an atomic conditional update.
	const updateEvent = `
		UPDATE events
		SET reserved_seats = $1
		WHERE id = $2`
	result, err := tx.ExecContext(ctx, updateEvent, newReservedSeats, reservation.EventID)
	if err != nil {
		return fmt.Errorf("update event seats: %w", translateError(err))
	}
	rows, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("count updated events: %w", err)
	}
	if rows != 1 {
		return booking.ErrNotFound
	}
	if err := tx.Commit(); err != nil {
		return fmt.Errorf("commit reservation: %w", translateError(err))
	}
	return nil
}

func (s *Store) ReservationByID(ctx context.Context, id booking.ID) (booking.Reservation, error) {
	const query = `
		SELECT id, event_id, customer_name, customer_email, seats,
		       status, expires_at, created_at
		FROM reservations
		WHERE id = $1`
	var reservation booking.Reservation
	err := s.db.QueryRowContext(ctx, query, id).Scan(
		&reservation.ID, &reservation.EventID, &reservation.CustomerName,
		&reservation.CustomerEmail, &reservation.Seats, &reservation.Status,
		&reservation.ExpiresAt, &reservation.CreatedAt,
	)
	if err != nil {
		return booking.Reservation{}, fmt.Errorf("select reservation: %w", translateError(err))
	}
	return reservation, nil
}
