//go:build integration && cgo

package postgres

import (
	"context"
	"database/sql"
	"os"
	"testing"
	"time"

	"example.com/seatkeeper/internal/booking"
	"example.com/seatkeeper/internal/pgdriver"
	platformmigrate "example.com/seatkeeper/internal/platform/migrate"
	"example.com/seatkeeper/migrations"
)

func TestStoreRoundTrip(t *testing.T) {
	databaseURL := os.Getenv("SEATKEEPER_TEST_DATABASE_URL")
	if databaseURL == "" {
		t.Skip("set SEATKEEPER_TEST_DATABASE_URL to run PostgreSQL integration tests")
	}

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	db, err := sql.Open(pgdriver.DriverName, databaseURL)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	if err := platformmigrate.Up(ctx, db, migrations.Files); err != nil {
		t.Fatal(err)
	}
	if _, err := db.ExecContext(ctx, "TRUNCATE reservations, events CASCADE"); err != nil {
		t.Fatal(err)
	}

	store := NewStore(db)
	event := booking.Event{
		ID: "00000000-0000-4000-8000-000000000101", Name: "Integration workshop",
		StartsAt: time.Date(2026, 11, 1, 10, 0, 0, 0, time.UTC),
		Capacity: 20, CreatedAt: time.Date(2026, 10, 3, 10, 0, 0, 0, time.UTC),
	}
	if err := store.CreateEvent(ctx, event); err != nil {
		t.Fatal(err)
	}

	reservation := booking.Reservation{
		ID: "00000000-0000-4000-8000-000000000102", EventID: event.ID,
		CustomerName: "Ada Lovelace", CustomerEmail: "ada@example.com",
		Seats: 2, Status: booking.ReservationHeld,
		ExpiresAt: time.Date(2026, 10, 3, 10, 10, 0, 0, time.UTC),
		CreatedAt: time.Date(2026, 10, 3, 10, 0, 0, 0, time.UTC),
	}
	if err := store.CreateReservation(ctx, reservation, 2); err != nil {
		t.Fatal(err)
	}

	gotEvent, err := store.EventByID(ctx, event.ID)
	if err != nil {
		t.Fatal(err)
	}
	if gotEvent.ReservedSeats != 2 {
		t.Fatalf("reserved seats = %d, want 2", gotEvent.ReservedSeats)
	}
	gotReservation, err := store.ReservationByID(ctx, reservation.ID)
	if err != nil {
		t.Fatal(err)
	}
	if gotReservation.CustomerEmail != reservation.CustomerEmail {
		t.Fatalf("customer email = %q, want %q", gotReservation.CustomerEmail, reservation.CustomerEmail)
	}
}
