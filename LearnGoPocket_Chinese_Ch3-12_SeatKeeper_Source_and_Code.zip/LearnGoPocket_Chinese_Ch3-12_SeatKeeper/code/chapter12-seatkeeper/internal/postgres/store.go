package postgres

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	"example.com/seatkeeper/internal/booking"
	"example.com/seatkeeper/internal/pgdriver"
)

// Store persists booking data in PostgreSQL.
type Store struct {
	db *sql.DB
}

// Open connects to PostgreSQL and verifies the connection.
func Open(ctx context.Context, databaseURL string) (*Store, error) {
	db, err := sql.Open(pgdriver.DriverName, databaseURL)
	if err != nil {
		return nil, fmt.Errorf("open PostgreSQL: %w", err)
	}
	db.SetMaxOpenConns(12)
	db.SetMaxIdleConns(4)
	if err := db.PingContext(ctx); err != nil {
		db.Close()
		return nil, fmt.Errorf("ping PostgreSQL: %w", err)
	}
	return &Store{db: db}, nil
}

// NewStore wraps an existing sql.DB. Tests and migration tooling can use it.
func NewStore(db *sql.DB) *Store { return &Store{db: db} }

func (s *Store) Close() error { return s.db.Close() }

func translateError(err error) error {
	if err == nil {
		return nil
	}
	if errors.Is(err, sql.ErrNoRows) {
		return booking.ErrNotFound
	}
	var postgresErr *pgdriver.Error
	if errors.As(err, &postgresErr) {
		switch postgresErr.Code {
		case "23505": // unique_violation
			return fmt.Errorf("%w: %s", booking.ErrConflict, postgresErr.Message)
		case "23503": // foreign_key_violation
			return fmt.Errorf("%w: %s", booking.ErrNotFound, postgresErr.Message)
		case "23514": // check_violation
			return fmt.Errorf("%w: %s", booking.ErrConflict, postgresErr.Message)
		}
	}
	return err
}
