package postgres

import (
	"context"
	"fmt"

	"example.com/seatkeeper/internal/booking"
)

func (s *Store) CreateEvent(ctx context.Context, event booking.Event) error {
	const query = `
		INSERT INTO events (
			id, name, starts_at, capacity, reserved_seats, created_at
		) VALUES ($1, $2, $3, $4, $5, $6)`
	_, err := s.db.ExecContext(ctx, query,
		event.ID, event.Name, event.StartsAt, event.Capacity,
		event.ReservedSeats, event.CreatedAt,
	)
	if err != nil {
		return fmt.Errorf("insert event: %w", translateError(err))
	}
	return nil
}

func (s *Store) ListEvents(ctx context.Context, limit int) ([]booking.Event, error) {
	const query = `
		SELECT id, name, starts_at, capacity, reserved_seats, created_at
		FROM events
		ORDER BY starts_at, id
		LIMIT $1`
	rows, err := s.db.QueryContext(ctx, query, limit)
	if err != nil {
		return nil, fmt.Errorf("query events: %w", translateError(err))
	}
	defer rows.Close()

	events := make([]booking.Event, 0)
	for rows.Next() {
		var event booking.Event
		if err := rows.Scan(
			&event.ID, &event.Name, &event.StartsAt, &event.Capacity,
			&event.ReservedSeats, &event.CreatedAt,
		); err != nil {
			return nil, fmt.Errorf("scan event: %w", err)
		}
		events = append(events, event)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate events: %w", err)
	}
	return events, nil
}

func (s *Store) EventByID(ctx context.Context, id booking.ID) (booking.Event, error) {
	const query = `
		SELECT id, name, starts_at, capacity, reserved_seats, created_at
		FROM events
		WHERE id = $1`
	var event booking.Event
	err := s.db.QueryRowContext(ctx, query, id).Scan(
		&event.ID, &event.Name, &event.StartsAt, &event.Capacity,
		&event.ReservedSeats, &event.CreatedAt,
	)
	if err != nil {
		return booking.Event{}, fmt.Errorf("select event: %w", translateError(err))
	}
	return event, nil
}
