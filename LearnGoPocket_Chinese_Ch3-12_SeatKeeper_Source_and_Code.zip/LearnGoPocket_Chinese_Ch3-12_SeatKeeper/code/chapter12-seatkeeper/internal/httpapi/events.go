package httpapi

import (
	"net/http"
	"strconv"
	"time"

	"example.com/seatkeeper/internal/booking"
)

type createEventRequest struct {
	Name     string    `json:"name"`
	StartsAt time.Time `json:"starts_at"`
	Capacity int       `json:"capacity"`
}

type eventResponse struct {
	booking.Event
	AvailableSeats int `json:"available_seats"`
}

func eventView(event booking.Event) eventResponse {
	return eventResponse{Event: event, AvailableSeats: event.AvailableSeats()}
}

func (s *Server) createEvent(w http.ResponseWriter, r *http.Request) {
	var request createEventRequest
	if err := decodeJSON(w, r, &request); err != nil {
		writeBadJSON(w, err)
		return
	}

	event, err := s.service.CreateEvent(r.Context(), booking.CreateEventInput{
		Name: request.Name, StartsAt: request.StartsAt, Capacity: request.Capacity,
	})
	if err != nil {
		writeServiceError(w, err)
		return
	}
	w.Header().Set("Location", "/v1/events/"+string(event.ID))
	writeJSON(w, http.StatusCreated, eventView(event))
}

func (s *Server) listEvents(w http.ResponseWriter, r *http.Request) {
	limit := 0
	if raw := r.URL.Query().Get("limit"); raw != "" {
		parsed, err := strconv.Atoi(raw)
		if err != nil {
			writeJSON(w, http.StatusUnprocessableEntity, errorEnvelope{Error: apiError{
				Code: "validation_error", Message: "request validation failed",
				Fields: map[string]string{"limit": "must be an integer"},
			}})
			return
		}
		limit = parsed
	}

	events, err := s.service.ListEvents(r.Context(), limit)
	if err != nil {
		writeServiceError(w, err)
		return
	}
	response := make([]eventResponse, 0, len(events))
	for _, event := range events {
		response = append(response, eventView(event))
	}
	writeJSON(w, http.StatusOK, map[string]any{"events": response})
}

func (s *Server) getEvent(w http.ResponseWriter, r *http.Request) {
	id, err := booking.ParseID(r.PathValue("eventID"))
	if err != nil {
		writeJSON(w, http.StatusNotFound, errorEnvelope{Error: apiError{
			Code: "not_found", Message: "the requested event does not exist",
		}})
		return
	}
	event, err := s.service.Event(r.Context(), id)
	if err != nil {
		writeServiceError(w, err)
		return
	}
	writeJSON(w, http.StatusOK, eventView(event))
}
