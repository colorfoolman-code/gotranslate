package httpapi

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"

	"example.com/seatkeeper/internal/booking"
)

const maxJSONBody = 1 << 20 // 1 MiB

type errorEnvelope struct {
	Error apiError `json:"error"`
}

type apiError struct {
	Code    string            `json:"code"`
	Message string            `json:"message"`
	Fields  map[string]string `json:"fields,omitempty"`
}

func decodeJSON(w http.ResponseWriter, r *http.Request, destination any) error {
	r.Body = http.MaxBytesReader(w, r.Body, maxJSONBody)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(destination); err != nil {
		return fmt.Errorf("decode JSON: %w", err)
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		return errors.New("request body must contain one JSON object")
	}
	return nil
}

func writeJSON(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	if err := json.NewEncoder(w).Encode(value); err != nil {
		// The response has already started. Logging is the only safe action left.
		return
	}
}

func writeServiceError(w http.ResponseWriter, err error) {
	var validationErr booking.ValidationError
	switch {
	case errors.As(err, &validationErr):
		writeJSON(w, http.StatusUnprocessableEntity, errorEnvelope{Error: apiError{
			Code: "validation_error", Message: "request validation failed", Fields: validationErr.Fields,
		}})
	case errors.Is(err, booking.ErrNotFound):
		writeJSON(w, http.StatusNotFound, errorEnvelope{Error: apiError{
			Code: "not_found", Message: "the requested resource does not exist",
		}})
	case errors.Is(err, booking.ErrNoSeatsAvailable):
		writeJSON(w, http.StatusConflict, errorEnvelope{Error: apiError{
			Code: "not_enough_seats", Message: "the event does not have enough available seats",
		}})
	case errors.Is(err, booking.ErrEventStarted):
		writeJSON(w, http.StatusConflict, errorEnvelope{Error: apiError{
			Code: "event_started", Message: "reservations are closed because the event has started",
		}})
	case errors.Is(err, booking.ErrConflict):
		writeJSON(w, http.StatusConflict, errorEnvelope{Error: apiError{
			Code: "conflict", Message: "the request conflicts with existing data",
		}})
	default:
		writeJSON(w, http.StatusInternalServerError, errorEnvelope{Error: apiError{
			Code: "internal_error", Message: "an unexpected error occurred",
		}})
	}
}

func writeBadJSON(w http.ResponseWriter, err error) {
	writeJSON(w, http.StatusBadRequest, errorEnvelope{Error: apiError{
		Code: "invalid_json", Message: err.Error(),
	}})
}
