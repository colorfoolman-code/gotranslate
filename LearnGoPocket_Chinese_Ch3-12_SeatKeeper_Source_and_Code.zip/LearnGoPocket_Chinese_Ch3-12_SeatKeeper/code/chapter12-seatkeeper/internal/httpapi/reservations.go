package httpapi

import (
	"net/http"

	"example.com/seatkeeper/internal/booking"
)

type createReservationRequest struct {
	CustomerName  string `json:"customer_name"`
	CustomerEmail string `json:"customer_email"`
	Seats         int    `json:"seats"`
}

func (s *Server) createReservation(w http.ResponseWriter, r *http.Request) {
	eventID, err := booking.ParseID(r.PathValue("eventID"))
	if err != nil {
		writeJSON(w, http.StatusNotFound, errorEnvelope{Error: apiError{
			Code: "not_found", Message: "the requested event does not exist",
		}})
		return
	}

	var request createReservationRequest
	if err := decodeJSON(w, r, &request); err != nil {
		writeBadJSON(w, err)
		return
	}
	reservation, err := s.service.CreateReservation(r.Context(), booking.CreateReservationInput{
		EventID: eventID, CustomerName: request.CustomerName,
		CustomerEmail: request.CustomerEmail, Seats: request.Seats,
	})
	if err != nil {
		writeServiceError(w, err)
		return
	}
	w.Header().Set("Location", "/v1/reservations/"+string(reservation.ID))
	writeJSON(w, http.StatusCreated, reservation)
}

func (s *Server) getReservation(w http.ResponseWriter, r *http.Request) {
	id, err := booking.ParseID(r.PathValue("reservationID"))
	if err != nil {
		writeJSON(w, http.StatusNotFound, errorEnvelope{Error: apiError{
			Code: "not_found", Message: "the requested reservation does not exist",
		}})
		return
	}
	reservation, err := s.service.Reservation(r.Context(), id)
	if err != nil {
		writeServiceError(w, err)
		return
	}
	writeJSON(w, http.StatusOK, reservation)
}
