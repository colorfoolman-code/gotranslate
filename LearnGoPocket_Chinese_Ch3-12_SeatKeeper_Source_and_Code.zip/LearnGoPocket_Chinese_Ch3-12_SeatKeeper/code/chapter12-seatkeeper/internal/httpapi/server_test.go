package httpapi

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"example.com/seatkeeper/internal/booking"
)

type stubService struct {
	createEventFn       func(context.Context, booking.CreateEventInput) (booking.Event, error)
	listEventsFn        func(context.Context, int) ([]booking.Event, error)
	eventFn             func(context.Context, booking.ID) (booking.Event, error)
	createReservationFn func(context.Context, booking.CreateReservationInput) (booking.Reservation, error)
	reservationFn       func(context.Context, booking.ID) (booking.Reservation, error)
}

func (s stubService) CreateEvent(ctx context.Context, input booking.CreateEventInput) (booking.Event, error) {
	return s.createEventFn(ctx, input)
}
func (s stubService) ListEvents(ctx context.Context, limit int) ([]booking.Event, error) {
	return s.listEventsFn(ctx, limit)
}
func (s stubService) Event(ctx context.Context, id booking.ID) (booking.Event, error) {
	return s.eventFn(ctx, id)
}
func (s stubService) CreateReservation(ctx context.Context, input booking.CreateReservationInput) (booking.Reservation, error) {
	return s.createReservationFn(ctx, input)
}
func (s stubService) Reservation(ctx context.Context, id booking.ID) (booking.Reservation, error) {
	return s.reservationFn(ctx, id)
}

func quietLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}

func unusedService() stubService {
	panicFn := func() { panic("unexpected service call") }
	return stubService{
		createEventFn: func(context.Context, booking.CreateEventInput) (booking.Event, error) {
			panicFn()
			return booking.Event{}, nil
		},
		listEventsFn: func(context.Context, int) ([]booking.Event, error) {
			panicFn()
			return nil, nil
		},
		eventFn: func(context.Context, booking.ID) (booking.Event, error) {
			panicFn()
			return booking.Event{}, nil
		},
		createReservationFn: func(context.Context, booking.CreateReservationInput) (booking.Reservation, error) {
			panicFn()
			return booking.Reservation{}, nil
		},
		reservationFn: func(context.Context, booking.ID) (booking.Reservation, error) {
			panicFn()
			return booking.Reservation{}, nil
		},
	}
}

func TestCreateEvent(t *testing.T) {
	t.Parallel()

	service := unusedService()
	service.createEventFn = func(_ context.Context, input booking.CreateEventInput) (booking.Event, error) {
		if input.Name != "Go in the Park" || input.Capacity != 80 {
			t.Fatalf("CreateEvent input = %#v", input)
		}
		return booking.Event{
			ID: "00000000-0000-4000-8000-000000000001", Name: input.Name,
			StartsAt: input.StartsAt, Capacity: input.Capacity,
		}, nil
	}
	handler := New(service, quietLogger())
	body := `{"name":"Go in the Park","starts_at":"2026-10-10T18:00:00Z","capacity":80}`
	request := httptest.NewRequest(http.MethodPost, "/v1/events", bytes.NewBufferString(body))
	recorder := httptest.NewRecorder()

	handler.ServeHTTP(recorder, request)

	if recorder.Code != http.StatusCreated {
		t.Fatalf("status = %d, want %d; body=%s", recorder.Code, http.StatusCreated, recorder.Body.String())
	}
	if got := recorder.Header().Get("Location"); got != "/v1/events/00000000-0000-4000-8000-000000000001" {
		t.Fatalf("Location = %q", got)
	}
	var response struct {
		Name           string `json:"name"`
		AvailableSeats int    `json:"available_seats"`
	}
	if err := json.Unmarshal(recorder.Body.Bytes(), &response); err != nil {
		t.Fatalf("decode response: %v", err)
	}
	if response.Name != "Go in the Park" || response.AvailableSeats != 80 {
		t.Fatalf("response = %#v", response)
	}
}

func TestCreateEventRejectsUnknownJSONField(t *testing.T) {
	t.Parallel()

	handler := New(unusedService(), quietLogger())
	body := `{"name":"Go in the Park","starts_at":"2026-10-10T18:00:00Z","capacity":80,"surprise":true}`
	request := httptest.NewRequest(http.MethodPost, "/v1/events", bytes.NewBufferString(body))
	recorder := httptest.NewRecorder()

	handler.ServeHTTP(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("status = %d, want %d", recorder.Code, http.StatusBadRequest)
	}
}

func TestGetEventMapsNotFound(t *testing.T) {
	t.Parallel()

	service := unusedService()
	service.eventFn = func(context.Context, booking.ID) (booking.Event, error) {
		return booking.Event{}, errors.Join(errors.New("query event"), booking.ErrNotFound)
	}
	handler := New(service, quietLogger())
	request := httptest.NewRequest(http.MethodGet, "/v1/events/00000000-0000-4000-8000-000000000009", nil)
	recorder := httptest.NewRecorder()

	handler.ServeHTTP(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("status = %d, want %d; body=%s", recorder.Code, http.StatusNotFound, recorder.Body.String())
	}
}

func TestListEventsRejectsNonIntegerLimit(t *testing.T) {
	t.Parallel()

	handler := New(unusedService(), quietLogger())
	request := httptest.NewRequest(http.MethodGet, "/v1/events?limit=lots", nil)
	recorder := httptest.NewRecorder()

	handler.ServeHTTP(recorder, request)

	if recorder.Code != http.StatusUnprocessableEntity {
		t.Fatalf("status = %d, want %d", recorder.Code, http.StatusUnprocessableEntity)
	}
}

func TestCreateReservation(t *testing.T) {
	t.Parallel()

	service := unusedService()
	service.createReservationFn = func(_ context.Context, input booking.CreateReservationInput) (booking.Reservation, error) {
		if input.Seats != 2 || input.EventID != "00000000-0000-4000-8000-000000000010" {
			t.Fatalf("CreateReservation input = %#v", input)
		}
		return booking.Reservation{
			ID: "00000000-0000-4000-8000-000000000011", EventID: input.EventID,
			CustomerName: input.CustomerName, CustomerEmail: input.CustomerEmail,
			Seats: 2, Status: booking.ReservationHeld,
			ExpiresAt: time.Date(2026, 10, 3, 10, 10, 0, 0, time.UTC),
		}, nil
	}
	handler := New(service, quietLogger())
	body := `{"customer_name":"Ada","customer_email":"ada@example.com","seats":2}`
	request := httptest.NewRequest(http.MethodPost, "/v1/events/00000000-0000-4000-8000-000000000010/reservations", bytes.NewBufferString(body))
	recorder := httptest.NewRecorder()

	handler.ServeHTTP(recorder, request)

	if recorder.Code != http.StatusCreated {
		t.Fatalf("status = %d, want %d; body=%s", recorder.Code, http.StatusCreated, recorder.Body.String())
	}
}

func TestWrongMethodReturnsMethodNotAllowed(t *testing.T) {
	t.Parallel()

	handler := New(unusedService(), quietLogger())
	request := httptest.NewRequest(http.MethodDelete, "/v1/events/00000000-0000-4000-8000-000000000010", nil)
	recorder := httptest.NewRecorder()

	handler.ServeHTTP(recorder, request)

	if recorder.Code != http.StatusMethodNotAllowed {
		t.Fatalf("status = %d, want %d", recorder.Code, http.StatusMethodNotAllowed)
	}
}
