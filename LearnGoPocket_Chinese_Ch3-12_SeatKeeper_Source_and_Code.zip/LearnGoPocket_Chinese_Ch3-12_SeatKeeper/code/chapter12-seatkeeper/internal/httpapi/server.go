package httpapi

import (
	"context"
	"log/slog"
	"net/http"

	"example.com/seatkeeper/internal/booking"
)

// Service contains only the use cases required by the HTTP adapter.
type Service interface {
	CreateEvent(context.Context, booking.CreateEventInput) (booking.Event, error)
	ListEvents(context.Context, int) ([]booking.Event, error)
	Event(context.Context, booking.ID) (booking.Event, error)
	CreateReservation(context.Context, booking.CreateReservationInput) (booking.Reservation, error)
	Reservation(context.Context, booking.ID) (booking.Reservation, error)
}

// Server translates HTTP requests into calls to the application service.
type Server struct {
	service Service
	logger  *slog.Logger
}

// New returns an HTTP handler for every SeatKeeper route.
func New(service Service, logger *slog.Logger) http.Handler {
	server := &Server{service: service, logger: logger}
	mux := http.NewServeMux()

	mux.HandleFunc("GET /healthz", server.health)
	mux.HandleFunc("POST /v1/events", server.createEvent)
	mux.HandleFunc("GET /v1/events", server.listEvents)
	mux.HandleFunc("GET /v1/events/{eventID}", server.getEvent)
	mux.HandleFunc("POST /v1/events/{eventID}/reservations", server.createReservation)
	mux.HandleFunc("GET /v1/reservations/{reservationID}", server.getReservation)

	return server.logRequests(mux)
}

func (s *Server) logRequests(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		s.logger.Info("http request", "method", r.Method, "path", r.URL.Path)
		next.ServeHTTP(w, r)
	})
}
