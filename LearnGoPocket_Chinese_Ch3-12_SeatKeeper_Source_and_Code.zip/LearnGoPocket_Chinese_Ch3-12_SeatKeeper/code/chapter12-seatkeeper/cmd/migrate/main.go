package main

import (
	"context"
	"database/sql"
	"fmt"
	"os"
	"time"

	"example.com/seatkeeper/internal/pgdriver"
	platformmigrate "example.com/seatkeeper/internal/platform/migrate"
	"example.com/seatkeeper/migrations"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, "migrate:", err)
		os.Exit(1)
	}
}

func run() error {
	databaseURL := getenv("DATABASE_URL", "postgres://seatkeeper:seatkeeper@localhost:5432/seatkeeper?sslmode=disable")
	db, err := sql.Open(pgdriver.DriverName, databaseURL)
	if err != nil {
		return err
	}
	defer db.Close()

	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()
	if err := db.PingContext(ctx); err != nil {
		return fmt.Errorf("connect to database: %w", err)
	}
	if err := platformmigrate.Up(ctx, db, migrations.Files); err != nil {
		return err
	}
	fmt.Println("database is up to date")
	return nil
}

func getenv(key, fallback string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return fallback
}
