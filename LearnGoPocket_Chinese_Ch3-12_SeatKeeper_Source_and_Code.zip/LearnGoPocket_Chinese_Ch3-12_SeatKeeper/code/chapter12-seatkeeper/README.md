# SeatKeeper - chapter 12 checkpoint

SeatKeeper is the continuous project introduced in chapter 12 of the Chinese auxiliary edition of *Learn Go with Pocket-Sized Projects*. This checkpoint contains the first vertical slice: a REST API, application service, PostgreSQL repository, SQL migrations, OpenAPI contract, unit tests, HTTP tests, and an optional PostgreSQL integration test.

## Requirements

- Go 1.23 or newer
- For native PostgreSQL builds: CGO, `pkg-config`, and the PostgreSQL client library (`libpq-dev` on Debian/Ubuntu, `libpq` via Homebrew on macOS)
- Docker Compose for the easiest full-system run

The repository contains no third-party Go modules. The small `internal/pgdriver` package delegates authentication and protocol details to the system `libpq` library. In a normal production project, using `github.com/jackc/pgx/v5` is recommended; the bundled driver keeps the chapter archive reproducible in an offline review environment.

## Run the checks

```bash
make fmt
make vet
make test
make test-race
make build
```

## Run the complete system with PostgreSQL

```bash
docker compose up --build -d
curl -fsS http://localhost:8080/healthz
./scripts/demo.sh
```

Stop and remove the database volume:

```bash
docker compose down -v
```

## Run the PostgreSQL integration test

Start PostgreSQL and apply migrations, then export a test URL:

```bash
export SEATKEEPER_TEST_DATABASE_URL='postgres://seatkeeper:seatkeeper@localhost:5432/seatkeeper?sslmode=disable'
CGO_ENABLED=1 go test -tags=integration ./internal/postgres
```

The test truncates the chapter tables. Use a disposable development database.

## API

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/healthz` | basic process health |
| `POST` | `/v1/events` | create an event |
| `GET` | `/v1/events` | list events |
| `GET` | `/v1/events/{eventID}` | read an event |
| `POST` | `/v1/events/{eventID}/reservations` | hold seats |
| `GET` | `/v1/reservations/{reservationID}` | read a hold |

The full contract is in `api/openapi.yaml`.

## Deliberate chapter boundary

This checkpoint checks availability before writing the new seat count. It is correct for sequential requests but is not safe when many requests compete for the last seats. That limitation is intentional: the next chapter starts with a concurrent test that exposes it, then introduces an atomic conditional update, transactions, idempotency, and optimistic concurrency control.
