// Package migrations exposes the SQL migration files to the migration command.
package migrations

import "embed"

// Files contains every numbered SQL migration.
//
//go:embed *.sql
var Files embed.FS
