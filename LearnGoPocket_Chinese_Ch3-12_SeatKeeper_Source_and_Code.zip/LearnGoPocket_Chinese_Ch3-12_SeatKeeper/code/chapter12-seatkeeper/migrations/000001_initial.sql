-- +migrate Up
CREATE TABLE IF NOT EXISTS events (
    id              uuid PRIMARY KEY,
    name            text        NOT NULL CHECK (char_length(btrim(name)) BETWEEN 3 AND 120),
    starts_at       timestamptz NOT NULL,
    capacity        integer     NOT NULL CHECK (capacity BETWEEN 1 AND 1000),
    reserved_seats  integer     NOT NULL DEFAULT 0 CHECK (reserved_seats >= 0),
    created_at      timestamptz NOT NULL
);

CREATE INDEX IF NOT EXISTS events_starts_at_idx
    ON events (starts_at, id);

CREATE TABLE IF NOT EXISTS reservations (
    id              uuid PRIMARY KEY,
    event_id        uuid        NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    customer_name   text        NOT NULL CHECK (char_length(btrim(customer_name)) BETWEEN 2 AND 120),
    customer_email  text        NOT NULL,
    seats           integer     NOT NULL CHECK (seats BETWEEN 1 AND 10),
    status          text        NOT NULL CHECK (status IN ('held')),
    expires_at      timestamptz NOT NULL,
    created_at      timestamptz NOT NULL
);

CREATE INDEX IF NOT EXISTS reservations_event_created_idx
    ON reservations (event_id, created_at DESC);

CREATE INDEX IF NOT EXISTS reservations_expires_at_idx
    ON reservations (expires_at)
    WHERE status = 'held';

-- +migrate Down
DROP TABLE IF EXISTS reservations;
DROP TABLE IF EXISTS events;
